"""<nombre> = open(<ruta del archivo>, <modo>)
close()
readable()
writable()
seekable()
write()
tell()
seek()"""