with EXPR as VAR:
    BLOCK