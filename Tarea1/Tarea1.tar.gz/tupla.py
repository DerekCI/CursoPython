a=(1, "a", 3.14)
print(a)