diccionario = {'nombre' : 'Carlos', 'edad' : 22, 'cursos': ['Python','Django','JavaScript'] }
print diccionario['nombre'] #Carlos
print diccionario['edad'] #22
print diccionario['cursos'] #['Python','Django','JavaScript']
