import saludo
saludo.saludoEntidad("todos")
saludo.saludoEntidad("programming historian")