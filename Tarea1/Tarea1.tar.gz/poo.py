class Persona:
    pass
