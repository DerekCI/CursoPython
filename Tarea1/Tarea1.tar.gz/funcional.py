def suma(val1=0, val2=0):
    return val1 + val2
