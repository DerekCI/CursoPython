lista = [1, 2.5, 'kereD', [5,6] ,4]
print(lista)