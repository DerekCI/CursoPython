mensaje1 = 'Hola' + ' ' + 'Mundo'
print(mensaje1)