flotante = 7.0
print(flotante)