entero = 7
print(entero)